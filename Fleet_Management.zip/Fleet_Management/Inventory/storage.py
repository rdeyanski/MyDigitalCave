import pickle
from datetime import datetime
now = datetime.now()
dt_string = now.strftime("%d/%m/%Y %H:%M:%S")

with open('inventory', 'rb') as inventory_file:
    inventory = pickle.load(inventory_file)


def current_time():
    now = datetime.now()
    dt_string = now.strftime("%d/%m/%Y %H:%M:%S")
    print(dt_string)


def beginning():
    count = 0
    print('\nAutomotive Inventory '
    '\n#1 Add Vehicle to Inventory '
    '\n#2 Delete Vehicle from Inventory'
    '\n#3 View Current Inventory'
    '\n#4 Update Vehicle from Inventory'
    '\n#5 Delete Current Inventory'
    '\n#6 Quit')
    for key, value in inventory.items():
        for k in value:
            if len(value[k]) > 1:
                count += 1
            else:
                count = 0
    if count == 0:
        print('Empty Inventory!\nOnly Options #1 and #6 Available')
    else:
        print('Please, choose from one of the above options:')


def add_vehicle():
    flag = False
    temp_list = []
    print('Please, enter type of vehicle: \n(SMALL, SEDAN, SUV, etc.)')
    type = input().upper()
    while type == '':
        print('Please, enter type of vehicle: \n(SMALL, SEDAN, SUV, etc.)')
        type = input().upper()
    if type not in inventory.keys():
        inventory[type] = {}
    print('Please, enter the license plate number:')
    plate_number = input().upper()
    while len(plate_number) < 7:
        print('Invalid Format! \nPlease, enter a valid license plate number:')
        plate_number = input().upper()
    for key, value in inventory.items():
        for k in value.keys():
            if k == plate_number:
                print('\n\nThis vehicle already exist in inventory!')
                print('VEHICLE DETAILS:')
                print('make:   ', value[k][0], '\nmodel:  ', value[k][1], '\nyear:   ', value[k][2],
                      '\ncolor:  ', value[k][3], '\nmileage:', value[k][4], '\nplate N:', k)
                current_time()
                print('-' * 20)
                flag = True
    if not flag:
        inventory[type][plate_number] = []
        print('Please, enter MAKE / MODEL / YEAR / COLOR / MILEAGE of new vehicle: ')
        for details in range(5):
            details = input().upper()
            temp_list.append(details)
        inventory[type][plate_number] = temp_list
        print('\n\nNEW VEHICLE ADDED:')
        print('{:.<10}'.format('type:'),'{:.<10}'.format(type),'\n''{:.<10}'.format('make:'),'{:.<10}'.format(temp_list[0])
              ,'\n''{:.<10}'.format('model:'),'{:.<10}'.format(temp_list[1]),'\n''{:.<10}'.format('year:'),
              '{:.<10}'.format(temp_list[2]),'\n''{:.<10}'.format('color:'),'{:.<10}'.format(temp_list[3]),
              '\n''{:.<10}'.format('mileage:'),'{:.<10}'.format(temp_list[4]),'\n''{:.<10}'.format('plate N:'),
              '{:.<10}'.format(plate_number))
        current_time()
        print('-'*20)
        temp_list = []


def del_vehicle():
    print('Please, input the license plate number of vehicle you want to remove:')
    plate_number = input().upper()
    flag = None
    for key, value in inventory.items():
        for k in value.keys():
            if k == plate_number:
                flag = True
                print('\nVehicle to remove from Inventory:')
                print('make:   ', value[k][0], '\nmodel:  ', value[k][1], '\nyear:   ', value[k][2],
                      '\ncolor:  ', value[k][3], '\nmileage:', value[k][4], '\nplate N:', k)
                print("\nPlease, press 'Y' to confirm")
                command1 = input().upper()
                if command1 == 'Y':
                    temp_string = k
                    del value[k]
                    print(f'Vehicle {temp_string} deleted')
                    current_time()
                    break
                else:
                    break
    if not flag:
        print('Invalid Number!')


def display():
    print("What type of Inventory you would like to see: \n('F'-full, 'S'-short, '1'-one vehicle)")
    command = input().upper()
    while command != 'F' and command != 'S' and command != '1':
        print("Invalid Display Option!\nPlease, enter one of three available options:"
              "\n('F'-full, 'S'-short, '1'-one vehicle)")
        command = input().upper()
    if command == 'S':
        print('\nMAKE / MODEL INVENTORY:')
        for key, value in inventory.items():
            print(f'.....................\n{key}')
            for k in value.keys():
                print('-', value[k][0], value[k][1])
        print('.'*20)
    elif command == 'F':
        print('\n\n{:-^62}'.format(' AUTOMOTIVE  INVENTORY '),'\n''{:.<10}'.format('make'),
              '{:.<10}'.format('model'),'{:.<10}'.format('year'),'{:.<10}'.format('color'),
              '{:.<10}'.format('mileage'),'{:<10}'.format('plate N:'))
        for key, value in inventory.items():
            for k in value.keys():
                print('{:<10}'.format(value[k][0]),'{:<10}'.format(value[k][1]),'{:<10}'.format(value[k][2]),
                      '{:<10}'.format(value[k][3]),'{:<10}'.format(value[k][4]),'{:<10}'.format(k))
        current_time()
        print('-'*64)
    elif command == '1':
        print('Please, input the license plate of vehicle you want to display:')
        plate_number = input().upper()
        flag = None
        for key, value in inventory.items():
            for k in value.keys():
                if k == plate_number:
                    flag = True
                    print('\nVEHICLE DETAILS:')
                    print('make:   ', value[k][0], '\nmodel:  ', value[k][1], '\nyear:   ', value[k][2],
                          '\ncolor:  ', value[k][3], '\nmileage:', value[k][4], '\nplate N:', k)
                    current_time()
                    print('-'*20)
                    break
        if not flag:
            print('Invalid Number!')


def update():
    print('Please, enter license plate number of vehicle you would like to update:')
    plate_number = input().upper()
    flag = None
    for key, value in inventory.items():
        for k in value.keys():
            if k == plate_number:
                flag = True
                print('\nVehicle to update:')
                print('make:   ',value[k][0],'\nmodel:  ',value[k][1],'\nyear:   ',value[k][2],
                      '\ncolor:  ',value[k][3],'\nmileage:',value[k][4],'\nplate N:', k)
                print("\nWhat detail you would like to update:\n('C'=color, 'M'=mileage, 'P'=plate N:)")
                command1 = input().upper()
                while command1 != 'C' and command1 != 'M' and command1 != 'P':
                    print("Invalid Detail!\nPlease, enter one of three options:\n'C'=color, 'M'=mileage, 'P'=plate N:")
                    command1 = input().upper()
                if command1 == 'C':
                    print('Please, enter new color:')
                    command2 = input().upper()
                    if command2 == '':
                        break
                    value[k][3] = command2
                elif command1 == 'M':
                    print('Please, enter new mileage:')
                    command2 = input()
                    if command2 == '':
                        break
                    value[k][4] = command2
                elif command1 == 'P':
                    print('Please, enter new license plate number:')
                    command2 = input().upper()
                    if command2 == '':
                        break
                    temp_list = []
                    temp_list = value[k]
                    inventory[key][command2] = temp_list
                    del inventory[key][k]
                    print('\nVehicle updated:')
                    print('make:   ', value[command2][0], '\nmodel:  ', value[command2][1], '\nyear:   ',value[command2][2],
                          '\ncolor:  ', value[command2][3], '\nmileage:', value[command2][4], '\nplate N:', command2)
                    current_time()
                    print('.'*20)
                    break
                else:
                    print('Invalid Detail!')
                    break
                print('\nVehicle updated:')
                print('make:   ', value[k][0], '\nmodel:  ', value[k][1], '\nyear:   ', value[k][2],
                      '\ncolor:  ', value[k][3], '\nmileage:', value[k][4], '\nplate N:', k)
                current_time()
                print('.'*20)
    if not flag:
        print('Invalid Number!')


def del_inventory():
    print('You have chosen option to clear whole inventory')
    print("Please, input 'DELETE' to confirm:")
    command = input().upper()
    if command == 'DELETE':
        for key, value in inventory.items():
            for k in value.keys():
                value[k] = []
            inventory[key] = {}
        print(f'Inventory Deleted:')
        current_time()


def next_step():
    command = input()
    if command:
        beginning()


def quit_inventory():
    with open('inventory', 'wb') as inventory_file:
        pickle.dump(inventory, inventory_file)
        quit()