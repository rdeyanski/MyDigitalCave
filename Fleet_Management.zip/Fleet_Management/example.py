# inventory = {'SMALL': {'CC5678DD': ['VW    ', 'POLO  ',  '2015', 'RED   ', ' 95000'],
#                        'CD3456BA': ['FIAT  ', '500    ', '2012', 'YELLOW', '102000'],
#                        'AC4321DB': ['FIAT  ', '500    ', '2013', 'RED   ', '135000'],
#                        'DB7658CA': ['FORD  ', 'FIESTA ', '2011', 'RED   ', '160000']},
#              'SEDAN': {'AA1234BB': ['VW    ', 'PASSAT ', '2015', 'SILVER', '134500'],
#                        'BB2345CC': ['FORD  ', 'FOCUS  ', '2018', 'BLACK ',  '30000'],
#                        'AB2345BC': ['FIAT  ', 'TIPO   ', '2014', 'BLUE  ', '105000']},
#                'SUV': {'AD5436DA': ['TOYOTA', 'RAV4   ', '2015', 'SILVER', '110000'],
#                        'BF2213CF': ['FORD  ', 'ESCAPE ', '2016', 'BLACK ', '110000']}}

# from datetime import datetime


# def current_time():
#    now = datetime.now()
#    dt_string = now.strftime("%d/%m/%Y %H:%M:%S")
#    print(dt_string)


#command = input()
#while True:
#    if command == '':
#        print('='*10, current_time())
#        pass
#    command = input()


