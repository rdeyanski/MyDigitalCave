from Inventory.storage import inventory, beginning, add_vehicle, del_vehicle,\
    display, update, next_step, del_inventory, quit_inventory


def main():
    while True:
        beginning()
        command = input()
        if inventory == {}:
            if command != '1':
                quit_inventory()
        if command == '6':
            quit_inventory()
        elif command == '1':
            add_vehicle()
            next_step()
        elif command == '2':
            del_vehicle()
            next_step()
        elif command == '3':
            display()
            next_step()
        elif command == '4':
            update()
            next_step()
        elif command == '5':
            del_inventory()
            quit_inventory()
        else:
            print("Invalid Choice!")
            next_step()


main()